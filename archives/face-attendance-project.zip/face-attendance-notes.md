# Face Attendance System: Project Notes

A web-based face-recognition attendance system to replace biometric (fingerprint) machines for **students, faculty and office staff**.

---

## 1. Conversation summary

### Goal
Build a website where people mark attendance by face instead of a biometric device.

### Users and roles
| Group | How attendance is tracked |
|---|---|
| Students | Marked "Present" (per day now; per class/lecture is a planned upgrade) |
| Faculty | Check-in and check-out times per day |
| Office staff | Check-in and check-out times per day |
| Admin | Enrolls/removes people, views and exports all records |

### How face attendance works
1. **Enrollment:** the admin captures 5 face samples. They are averaged into one 128-number "embedding" (face descriptor). Raw photos are not stored.
2. **Recognition:** at check-in the camera computes an embedding and compares it with stored ones. If the distance is below the threshold (0.5), the person is identified.
3. **Recording:** attendance is saved with date, time, type and match confidence.
4. **Reports:** the admin filters by date and exports to CSV (opens in Excel).

### Decisions made
- First, a quick **single-file browser prototype** (`face-attendance.html`) to test the idea.
- Then, a **proper VS Code project** (`face-attendance-project.zip`) with a Python backend, because the user wanted a separate project.

### Final project structure
```
face-attendance/
├── main.py            # FastAPI backend: API, SQLite database, face matching, admin login
├── requirements.txt   # fastapi, uvicorn
├── README.md
├── .gitignore
├── attendance.db      # created automatically on first run
└── static/
    ├── index.html     # web interface
    ├── style.css
    └── app.js         # camera, face detection, admin panel
```

### How to run (VS Code)
1. Unzip and open the `face-attendance` folder in VS Code.
2. Create a virtual environment:
   - Windows: `python -m venv .venv` then `.venv\Scripts\activate`
   - Mac/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
3. Install: `pip install -r requirements.txt`
4. Start: `uvicorn main:app --reload`
5. Open `http://localhost:8000` and allow camera access (internet is needed on first load for the face models).

Default admin password is `admin123`. Change it before real use:
- Windows (PowerShell): `$env:ADMIN_PASSWORD="your-password"; uvicorn main:app --reload`
- Mac/Linux: `ADMIN_PASSWORD=your-password uvicorn main:app --reload`

### API endpoints
| Method | Path | Access | Purpose |
|---|---|---|---|
| POST | `/api/login` | Public | Admin login, returns a token |
| GET | `/api/people` | Admin | List enrolled people |
| POST | `/api/people` | Admin | Enroll a person with face data |
| DELETE | `/api/people/{id}` | Admin | Remove a person |
| POST | `/api/checkin` | Public | Match a face and record attendance |
| GET | `/api/attendance?date=` | Admin | Get records |

---

## 2. Resources

### Software (all free and open source)
| Resource | Used for |
|---|---|
| Python 3.9+ | Backend language |
| FastAPI | Web framework / API |
| Uvicorn | Server that runs FastAPI |
| SQLite | Database (built into Python, no install) |
| face-api.js (@vladmandic fork) | Face detection and 128-number face descriptors in the browser |
| VS Code | Code editor |
| A modern browser (Chrome, Edge, Firefox) | Camera access via `getUserMedia` |

### Hardware
- A computer or tablet at each check-in point, with a **webcam** (720p or better recommended).
- Good, even lighting at the camera position.
- Reliable network between the kiosk and the server (or run both on the same machine).

### People and knowledge needed
- Basic Python and JavaScript to maintain it.
- Someone to act as admin (enrolls people, exports reports).
- Written consent process for storing face data.

### Useful learning links
- FastAPI docs: https://fastapi.tiangolo.com
- face-api.js (vladmandic): https://github.com/vladmandic/face-api
- MDN `getUserMedia`: https://developer.mozilla.org/docs/Web/API/MediaDevices/getUserMedia
- SQLite: https://www.sqlite.org/docs.html

### Cost
- **Software: free.**
- Hardware: only webcams/tablets. This is usually far cheaper than a commercial biometric terminal per door.
- Hosting (optional): a small VPS or a spare office PC is enough for a few hundred users.

---

## 3. Drawbacks and limitations

### Security
- **No liveness detection.** A printed photo or a phone screen showing someone's face can fool the system. This is the biggest weakness.
- **Simple admin login.** One shared password and in-memory tokens (reset when the server restarts). There are no individual admin accounts and no brute-force lockout.
- **`/api/checkin` is public.** Anyone who can reach the server can send scans to it.
- **Database is not encrypted.** Face embeddings in `attendance.db` are biometric data and need protection.
- **HTTP only on localhost.** Real deployment needs HTTPS (browsers also require it for the camera).

### Accuracy
- Affected by **poor lighting, angles, masks, glasses, heavy beard changes** and low-quality webcams.
- **Look-alikes and twins** can cause false matches. The 0.5 threshold is a trade-off: stricter means more "not recognised", looser means more false matches.
- Matching compares against everyone in the database one by one. This is fine for hundreds of people but slow for tens of thousands.
- Models are small and fast, so they are less accurate than heavy server-side models such as InsightFace/ArcFace.
- Faces change over time (age, appearance), so re-enrollment may be needed.

### Functional gaps
- Students are tracked **per day, not per class or lecture**.
- No late/absent rules, holidays, leave management or shift settings.
- No self-service view for students or faculty to see their own attendance.
- No bulk enrollment (CSV/photos) for large numbers of students.
- Basic reporting only: date filter and CSV export, with no charts or monthly summaries.
- No email or SMS notifications.
- A forgotten check-out cannot be corrected by the admin yet.

### Technical
- Face models load from a **CDN**, so internet is needed unless the model files are hosted locally.
- Each kiosk needs a browser tab left open with camera permission.
- **SQLite** is fine for small to medium use but not for many simultaneous kiosks writing at once; move to PostgreSQL/MySQL for scale.
- Not tested with a real camera in this environment, so expect small fixes during your first run.

### Privacy and legal
- Face data is **sensitive biometric data**. Many regions require explicit consent, a clear purpose, secure storage and a deletion process.
- Students who are minors may need parental consent.
- You need an alternative method (for example manual entry) for people who decline or cannot be recognised.
- Check your local data-protection law and institutional policy before going live.

---

## 4. Recommended next steps (priority order)
1. **Liveness detection:** blink or head-turn challenge to stop photo spoofing.
2. **Security hardening:** individual admin accounts with hashed passwords, HTTPS, rate limiting, encrypted database or disk.
3. **Class-wise attendance:** timetable, courses, and per-lecture marking for students and faculty.
4. **Rules and reports:** late/absent thresholds, holidays, monthly summaries, PDF/Excel exports.
5. **Role dashboards:** students and faculty log in to see their own attendance percentage.
6. **Scale:** PostgreSQL, server-side recognition (InsightFace) and local model hosting for offline use.
7. **Bulk enrollment:** import students from CSV with photos.

---

## 5. Quick FAQ
**Does it store photos?** No. It stores only a 128-number embedding per person, which can still be treated as biometric data.

**Can it work offline?** Only if you download the face-api model files and serve them locally instead of from the CDN.

**Can it replace a biometric machine today?** It works as a prototype or pilot. For a full replacement, add liveness detection, security hardening and the missing attendance rules first.
