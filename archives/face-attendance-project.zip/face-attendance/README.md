# Face Attendance (FastAPI + SQLite)

Face-recognition attendance for students, faculty and office staff.

## Run in VS Code
1. Open this folder in VS Code (File > Open Folder).
2. Open a terminal (Ctrl+`) and create a virtual environment:
   - Windows: `python -m venv .venv` then `.venv\Scripts\activate`
   - Mac/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
3. Install: `pip install -r requirements.txt`
4. Start: `uvicorn main:app --reload`
5. Open http://localhost:8000 and allow camera access (internet needed on first load for face models).

## Use
- **Admin tab** - log in (default password `admin123`), enroll people, view/export records.
- **Check in tab** - leave this open on the kiosk computer; faces are recognised automatically.

Set a real password before using it for real:
- Windows (PowerShell): `$env:ADMIN_PASSWORD="your-password"; uvicorn main:app --reload`
- Mac/Linux: `ADMIN_PASSWORD=your-password uvicorn main:app --reload`

## Files
- `main.py` - API, database, face matching, admin login
- `static/index.html`, `style.css`, `app.js` - the web interface
- `attendance.db` - created automatically on first run

## Notes
- No liveness check yet: a photo of a face can fool it. Add blink/head-turn detection before real deployment.
- Use HTTPS if you deploy beyond localhost (browsers require it for the camera).
- Face data is biometric data: get consent and restrict access to the database file.
