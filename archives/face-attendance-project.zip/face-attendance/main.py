"""Face attendance backend (FastAPI + SQLite).
Face descriptors are stored and matched on the server, so the browser never receives them.
"""
import json, math, os, secrets, sqlite3
from datetime import datetime
from fastapi import FastAPI, Header, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")  # change this!
THRESHOLD = 0.5          # lower = stricter matching
COOLDOWN_SECONDS = 60    # ignore repeat scans within this time
DB = "attendance.db"
tokens = set()
app = FastAPI(title="Face Attendance")


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


with db() as c:
    c.executescript("""
    CREATE TABLE IF NOT EXISTS people(
        id TEXT PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL, descriptor TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS attendance(
        rid INTEGER PRIMARY KEY AUTOINCREMENT, person_id TEXT, name TEXT, role TEXT,
        date TEXT, time TEXT, type TEXT, conf INTEGER);
    """)


def need_admin(token):
    if token not in tokens:
        raise HTTPException(401, "Admin login required")


class Login(BaseModel):
    password: str

class Person(BaseModel):
    id: str
    name: str
    role: str
    descriptor: list[float]

class Scan(BaseModel):
    descriptor: list[float]


@app.post("/api/login")
def login(b: Login):
    if not secrets.compare_digest(b.password, ADMIN_PASSWORD):
        raise HTTPException(401, "Wrong password")
    t = secrets.token_hex(16)
    tokens.add(t)
    return {"token": t}


@app.get("/api/people")
def people(x_token: str = Header(None)):
    need_admin(x_token)
    with db() as c:
        return [dict(r) for r in c.execute("SELECT id,name,role FROM people ORDER BY name")]


@app.post("/api/people")
def add_person(p: Person, x_token: str = Header(None)):
    need_admin(x_token)
    if len(p.descriptor) != 128:
        raise HTTPException(400, "Bad face data")
    try:
        with db() as c:
            c.execute("INSERT INTO people VALUES(?,?,?,?)",
                      (p.id.strip(), p.name.strip(), p.role, json.dumps(p.descriptor)))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "That ID is already enrolled")
    return {"ok": True}


@app.delete("/api/people/{pid}")
def del_person(pid: str, x_token: str = Header(None)):
    need_admin(x_token)
    with db() as c:
        c.execute("DELETE FROM people WHERE id=?", (pid,))
    return {"ok": True}


@app.post("/api/checkin")
def checkin(s: Scan):
    best, best_d = None, 9.0
    with db() as c:
        for r in c.execute("SELECT * FROM people"):
            d = math.dist(s.descriptor, json.loads(r["descriptor"]))
            if d < best_d:
                best, best_d = r, d
        if best is None or best_d > THRESHOLD:
            return {"status": "unknown"}
        now = datetime.now()
        today = now.strftime("%Y-%m-%d")
        rows = c.execute("SELECT date,time FROM attendance WHERE person_id=? AND date=? ORDER BY rid DESC",
                         (best["id"], today)).fetchall()
        if rows:
            last = datetime.strptime(rows[0]["date"] + " " + rows[0]["time"], "%Y-%m-%d %H:%M:%S")
            if (now - last).total_seconds() < COOLDOWN_SECONDS:
                return {"status": "cooldown", "name": best["name"]}
        if best["role"] == "Student":
            typ = "Present" if not rows else "Present (repeat)"
        else:
            typ = "Check-in" if len(rows) % 2 == 0 else "Check-out"
        t = now.strftime("%H:%M:%S")
        c.execute("INSERT INTO attendance(person_id,name,role,date,time,type,conf) VALUES(?,?,?,?,?,?,?)",
                  (best["id"], best["name"], best["role"], today, t, typ, round((1 - best_d) * 100)))
        return {"status": "ok", "name": best["name"], "type": typ, "time": t}


@app.get("/api/attendance")
def attendance(date: str = "", x_token: str = Header(None)):
    need_admin(x_token)
    q, a = "SELECT * FROM attendance", ()
    if date:
        q, a = q + " WHERE date=?", (date,)
    with db() as c:
        return [dict(r) for r in c.execute(q + " ORDER BY rid DESC", a)]


app.mount("/", StaticFiles(directory="static", html=True), name="static")
