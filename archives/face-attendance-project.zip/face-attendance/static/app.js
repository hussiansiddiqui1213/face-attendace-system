const MODELS = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.12/model/';
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today = () => new Date().toLocaleDateString('en-CA');
const detOpts = () => new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 });
let tab = 'checkin', ready = false, busyUntil = 0, showAll = false, token = sessionStorage.getItem('token') || '';

async function api(path, method = 'GET', body) {
  const r = await fetch('/api' + path, {
    method, headers: { 'Content-Type': 'application/json', 'X-Token': token },
    body: body ? JSON.stringify(body) : undefined
  });
  if (r.status === 401 && path !== '/login') logout();
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.detail || 'Request failed');
  return data;
}

async function init() {
  try {
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODELS),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODELS),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODELS)]);
    const s = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
    $('v1').srcObject = s; $('v2').srcObject = s;
    ready = true; $('load').remove(); loop();
  } catch (e) {
    $('load').className = 'bad';
    $('load').textContent = 'Could not start: ' + e.message + '. Use http://localhost:8000, allow the camera, and check your internet (models load from a CDN).';
  }
}

async function loop() {
  if (ready && tab === 'checkin' && Date.now() > busyUntil) {
    try {
      const r = await faceapi.detectSingleFace($('v1'), detOpts()).withFaceLandmarks().withFaceDescriptor();
      if (!r) $('st').innerHTML = '<span class="mute">No face detected. Look at the camera.</span>';
      else {
        const res = await api('/checkin', 'POST', { descriptor: Array.from(r.descriptor) });
        if (res.status === 'ok') { $('st').innerHTML = `<span class="ok">${esc(res.name)}: ${res.type} at ${res.time}</span>`; busyUntil = Date.now() + 4000; }
        else if (res.status === 'cooldown') { $('st').innerHTML = `<span class="ok">${esc(res.name)}: already recorded.</span>`; busyUntil = Date.now() + 3000; }
        else $('st').innerHTML = '<span class="bad">Face not recognised.</span>';
      }
    } catch (e) { $('st').innerHTML = '<span class="bad">' + esc(e.message) + '</span>'; busyUntil = Date.now() + 3000; }
  }
  setTimeout(loop, 600);
}

$('nav').onclick = e => {
  const t = e.target.dataset.t; if (!t) return; tab = t;
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.t === t));
  document.querySelectorAll('section').forEach(s => s.classList.toggle('on', s.id === t));
};

/* ---- admin ---- */
function showAdmin() {
  $('loginBox').hidden = !!token; $('adminBox').hidden = !token;
  if (token) { loadPeople(); loadLog(); }
}
function logout() { token = ''; sessionStorage.removeItem('token'); showAdmin(); }
$('logout').onclick = logout;
$('loginBtn').onclick = async () => {
  try {
    const r = await api('/login', 'POST', { password: $('pw').value });
    token = r.token; sessionStorage.setItem('token', token); $('pw').value = ''; $('lerr').textContent = ''; showAdmin();
  } catch (e) { $('lerr').textContent = e.message; }
};
$('pw').onkeydown = e => { if (e.key === 'Enter') $('loginBtn').click(); };

$('cap').onclick = async () => {
  const name = $('nm').value.trim(), id = $('pid').value.trim();
  const es = $('es'); es.className = 'status mute';
  if (!name || !id) { es.textContent = 'Enter a name and ID first.'; return; }
  $('cap').disabled = true;
  const ds = []; let tries = 0;
  while (ds.length < 5 && tries < 40) {
    tries++; es.textContent = `Capturing ${ds.length}/5… hold still, turn slightly between samples.`;
    const r = await faceapi.detectSingleFace($('v2'), detOpts()).withFaceLandmarks().withFaceDescriptor();
    if (r) ds.push(r.descriptor);
    await new Promise(r => setTimeout(r, 500));
  }
  $('cap').disabled = false;
  if (ds.length < 5) { es.className = 'status bad'; es.textContent = 'Could not capture a clear face. Improve lighting and try again.'; return; }
  const avg = new Array(128).fill(0);
  ds.forEach(d => d.forEach((v, i) => avg[i] += v / ds.length));
  try {
    await api('/people', 'POST', { id, name, role: $('rl').value, descriptor: avg });
    es.className = 'status ok'; es.textContent = name + ' enrolled.';
    $('nm').value = ''; $('pid').value = ''; loadPeople();
  } catch (e) { es.className = 'status bad'; es.textContent = e.message; }
};

async function loadPeople() {
  const list = await api('/people');
  $('ppl').innerHTML = '<tr><th>Name</th><th>ID</th><th>Role</th><th></th></tr>' +
    (list.length ? list.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.id)}</td><td>${esc(p.role)}</td><td><button class="s" data-rm="${esc(p.id)}">Remove</button></td></tr>`).join('')
      : '<tr><td colspan="4" class="mute">No one enrolled yet. Capture a face above.</td></tr>');
}
$('ppl').onclick = async e => {
  const id = e.target.dataset.rm;
  if (id && confirm('Remove this person and their face data?')) { await api('/people/' + encodeURIComponent(id), 'DELETE'); loadPeople(); }
};

let rows = [];
async function loadLog() {
  rows = await api('/attendance' + (showAll ? '' : '?date=' + $('d').value));
  $('lg').innerHTML = '<tr><th>Date</th><th>Time</th><th>Name</th><th>ID</th><th>Role</th><th>Type</th><th>Match</th></tr>' +
    (rows.length ? rows.map(l => `<tr><td>${l.date}</td><td>${l.time}</td><td>${esc(l.name)}</td><td>${esc(l.person_id)}</td><td>${esc(l.role)}</td><td>${l.type}</td><td>${l.conf}%</td></tr>`).join('')
      : '<tr><td colspan="7" class="mute">No records for this selection.</td></tr>');
}
$('d').value = today();
$('d').onchange = () => { showAll = false; loadLog(); };
$('all').onclick = () => { showAll = true; loadLog(); };
$('csv').onclick = () => {
  const q = s => '"' + String(s).replace(/"/g, '""') + '"';
  const csv = ['Date,Time,Name,ID,Role,Type,Match'].concat(rows.map(l => [l.date, l.time, l.name, l.person_id, l.role, l.type, l.conf].map(q).join(','))).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'attendance.csv'; a.click();
};

showAdmin(); init();
